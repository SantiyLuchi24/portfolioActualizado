<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $firstName = htmlspecialchars($_POST['nombre']);
    $email = htmlspecialchars($_POST['correo']);
    $message = htmlspecialchars($_POST['mensaje']);
    
    // Formato de los datos para escribir en el archivo
    $data = "Nombre: $firstName\n";
    $data .= "Correo Electrónico: $email\n";
    $data .= "Mensaje: $message\n";
    $data .= "---------------------------\n";

    // Escribir los datos en un archivo de texto
    $file = 'registros.txt';
    file_put_contents($file, $data, FILE_APPEND);

    // Confirmación de registro
    echo "Registro exitoso.";
}
?>