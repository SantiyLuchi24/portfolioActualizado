<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $firstName = htmlspecialchars($_POST['first-name']);
    $lastName = htmlspecialchars($_POST['last-name']);
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    $confirmPassword = htmlspecialchars($_POST['confirm-password']);

    // Formato de los datos para escribir en el archivo
    $data = "Nombre: $firstName\n";
    $data .= "Apellido: $lastName\n";
    $data .= "Correo Electrónico: $email\n";
    $data .= "Contraseña: $password\n";
    $data .= "Confirmar Contraseña: $confirmPassword\n";
    $data .= "---------------------------\n";

    // Escribir los datos en un archivo de texto
    $file = 'registros.txt';
    file_put_contents($file, $data, FILE_APPEND);

    // Confirmación de registro
    echo "Registro exitoso.";
}
?>
