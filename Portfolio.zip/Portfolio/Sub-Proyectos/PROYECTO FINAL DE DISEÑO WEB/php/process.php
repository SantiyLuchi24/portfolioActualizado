<?php
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$telefono = $_POST['telefono'];
$mensaje = $_POST['mensaje'];
$limiteCaracteres = 1000;

if (empty($nombre) || empty($email) || empty($telefono) || empty($mensaje)) {

    echo 'Por favor, completa todos los campos del formulario.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo 'Por favor, ingresa un correo electrónico válido.';
} elseif (!preg_match('/^[0-9]+$/', $telefono)) {
    echo 'Por favor, ingresa un número de teléfono válido.';
} elseif (strlen($mensaje) > $limiteCaracteres) {
    echo 'El mensaje debe tener un máximo de ' . $limiteCaracteres . ' caracteres.';
} else {

    echo '¡Gracias! Tu mensaje ha sido enviado correctamente.';
}

$host = 'localhost';
$usuario = 'usuario';
$contrasena = 'contrasena';
$basedatos = 'nombre_de_la_base_de_datos';

$conexion = mysqli_connect($host, $usuario, $contrasena, $basedatos);

if (!$conexion) {
    die('Error al conectar con la base de datos: ' . mysqli_connect_error());
}

$query = "INSERT INTO tabla_contacto (nombre, email, telefono, mensaje) VALUES ('$nombre', '$email', '$telefono', '$mensaje')";
$resultado = mysqli_query($conexion, $query);

if ($resultado) {
    echo '¡Gracias! Tu mensaje ha sido enviado correctamente.';
} else {
    echo 'Ha ocurrido un error al enviar el mensaje. Por favor, inténtalo nuevamente.';
}
mysqli_close($conexion);
?>